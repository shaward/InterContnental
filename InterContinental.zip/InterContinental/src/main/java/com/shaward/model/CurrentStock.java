package com.shaward.model;


public  class CurrentStock {

	static Stock currentStock= new Stock();


	public static Stock getCurrentStock() {
		return currentStock;
	}

	public static void setCurrentStock(Stock currentStock) {
		CurrentStock.currentStock = currentStock;
	}

}