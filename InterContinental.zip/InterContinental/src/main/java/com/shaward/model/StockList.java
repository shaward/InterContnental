package com.shaward.model;


import java.util.ArrayList;
import java.util.List;

public  class StockList {
	static List<Stock> stocklist = new ArrayList<Stock>();


	public static List<Stock> getStocklist() {
		return stocklist;
	}


}