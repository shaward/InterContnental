package com.shaward.writer;

import com.shaward.model.CurrentStock;
import com.shaward.model.Report;
import com.shaward.model.Stock;
import com.shaward.model.StockList;
import org.apache.commons.lang.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import java.util.List;


public class TokenDataWriter implements ItemWriter<Report> {
    final Logger logger = LoggerFactory.getLogger(TokenDataWriter.class);


    public void write(List<? extends Report> items) throws Exception {
        int result;
       // List <Stock> stocklist = new ArrayList<Stock>();
       // List <String> namelist = new ArrayList<String>();
        Stock currentStock= CurrentStock.getCurrentStock();
        int idx = 0;
        boolean newStock = false;
       
        logger.info("items size =" + items.size());

        for (Report item : items) {
            try {
                logger.info("reading token:" + item.getToken());

                // check token
                String token = item.getToken();
                if (NumberUtils.isNumber(token)) // price
                {
                    currentStock.setLastPrice(token);

                    //StockList.getCurrentStock().    currentStock.setName(StockList.getStocklist().get(size - 1).getName());



                        idx = findStock(StockList.getStocklist(), currentStock.getName());
                        if (idx != -1){
                            // update entry in list
                            StockList.getStocklist().set(idx,currentStock);
                        }
                        else {
                            logger.info("error finding:" + currentStock != null ? currentStock.getName(): "");
                        }


                }
                // stock
                else {

                    idx = findStock(StockList.getStocklist(), token );
                    // if not there
                    if (idx == -1){
                        // new stock
                        newStock = true;
                        Stock stock = new Stock();
                        stock.setName(token);
                        StockList.getStocklist().add(stock);
                        currentStock = stock;

                    }
                }

            } catch (Exception e) {
                logger.info("token:" + item.getToken());
                logger.info(e.getMessage());
                e.printStackTrace();

            }
        } // for
        CurrentStock.setCurrentStock(currentStock);

    }

    // find stock name in list
    int findStock( List <Stock> stocklist, String name){
        for ( int i = 0 ; i < stocklist.size(); i++){
                Stock entry = stocklist.get(i);
            try {
                if (entry.getName().equals(name)) {
                    return i;
                }
            }
            catch(Exception e){
                logger.info(e.getMessage());
            }
          }
        return -1;
    }

}

