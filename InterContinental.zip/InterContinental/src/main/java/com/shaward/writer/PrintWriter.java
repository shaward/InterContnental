package com.shaward.writer;

import com.shaward.model.Stock;
import com.shaward.model.StockList;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;


public class PrintWriter implements Tasklet {


    @Override
    public RepeatStatus execute(StepContribution contribution,
                                ChunkContext chunkContext) throws Exception {

        System.out.println("Stock" + "\t" + "Price");
        for (int i = 0; i < StockList.getStocklist().size(); i++){
            Stock entry = StockList.getStocklist().get(i);
            System.out.println(entry.getName() + "\t" + entry.getLastPrice());
        }
        return RepeatStatus.FINISHED;
    }

}

