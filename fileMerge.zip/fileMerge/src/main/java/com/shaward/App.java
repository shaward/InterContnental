/*
assume the files contain text strings
 */

package com.shaward;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class App {
	public static void main(String[] args) {
		try {

			String curDir = System.getProperty("user.dir");
			File file1 = new File(curDir + "/src/main/resources/data/input/merge1.txt");
			FileReader fileReader1 = new FileReader(file1);
			File file2 = new File(curDir + "/src/main/resources/data/input/merge2.txt");
			FileReader fileReader2 = new FileReader(file2);
			BufferedReader bufferedReader1 = new BufferedReader(fileReader1);
			BufferedReader bufferedReader2 = new BufferedReader(fileReader2);
			StringBuffer stringBuffer = new StringBuffer();
			String line1= null;
			String line2=null;
			String hold= null;
			String hold2= null;
			int compare = 0;
			boolean first =false;
			System.out.println("merged file:");
			while (true) {
				if (!first) {
					line1 = bufferedReader1.readLine();
					first= true;
				}
				if (line1 == null)
					break;
				if (hold == null) {
					line2 = bufferedReader2.readLine();
					compare = line1.compareTo(line2);
				}else {
					// check who is holding
                    if (line2.compareTo(hold) == 0){   // line1 holding
						line1 = bufferedReader1.readLine();
						if (line1 == null){
							break;
						}
						compare = line1.compareTo(hold);
						line2 = hold;
					}else {
						// line2 holding
						line2 = bufferedReader2.readLine();
						if (line2 == null){
							break;
						}
						compare = hold.compareTo(line2);
						line1 = hold;
					}
				}

				if (compare < 0){
					System.out.println(line1);
					hold = line2;
				}
				else if (compare > 0) {
					System.out.println(line2);
					hold = line1;
				}
				else {
					System.out.println(line2);
					hold = line1;
				}
				//stringBuffer.append(line);
				//stringBuffer.append("\n");
			}
			if (line1 == null && line2 != null){
				System.out.println(line2);
				while ( (line2 = bufferedReader2.readLine()) != null){
					System.out.println(line2);
				}
			}
			if (line2 == null &&  line1 != null){
				System.out.println(line1);
				while ( (line1 = bufferedReader1.readLine()) != null){
					System.out.println(line1);
				}
			}
			fileReader1.close();
			fileReader2.close();
			//System.out.println(stringBuffer.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
